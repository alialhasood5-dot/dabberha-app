export const ADMIN_EMAIL = "alialhasood5@gmail.com";
export const ADMIN_COOKIE_NAME = "dabrha_admin_session";
export const ADMIN_SESSION_MS = 1000 * 60 * 60 * 12;
