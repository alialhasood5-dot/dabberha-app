CREATE TABLE `admin_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`passwordHash` varchar(256) NOT NULL,
	`passwordSalt` varchar(128) NOT NULL,
	`failedAttempts` int NOT NULL DEFAULT 0,
	`lockedUntil` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastLoginAt` timestamp,
	CONSTRAINT `admin_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `admin_accounts_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `commission_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ratePercent` decimal(5,2) NOT NULL DEFAULT '10.00',
	`collectionMethod` varchar(80) NOT NULL DEFAULT 'زين كاش',
	`freeLaunchUntil` timestamp,
	`freezeThreshold` int NOT NULL DEFAULT 100000,
	`updatedByAdminId` int NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `commission_settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `offers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`requestId` int NOT NULL,
	`technicianId` int NOT NULL,
	`amount` int NOT NULL,
	`note` text,
	`status` enum('pending','accepted','rejected','withdrawn') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `offers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `provinces` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`sortOrder` int NOT NULL DEFAULT 0,
	CONSTRAINT `provinces_id` PRIMARY KEY(`id`),
	CONSTRAINT `provinces_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `ratings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`requestId` int NOT NULL,
	`homeownerId` int NOT NULL,
	`technicianId` int NOT NULL,
	`stars` int NOT NULL,
	`comment` text,
	`isHidden` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ratings_id` PRIMARY KEY(`id`),
	CONSTRAINT `ratings_requestId_unique` UNIQUE(`requestId`)
);
--> statement-breakpoint
CREATE TABLE `service_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publicCode` varchar(24) NOT NULL,
	`homeownerId` int NOT NULL,
	`provinceId` int NOT NULL,
	`serviceId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text NOT NULL,
	`budgetMin` int,
	`budgetMax` int,
	`status` enum('open','assigned','in_progress','awaiting_confirmation','completed','cancelled') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `service_requests_id` PRIMARY KEY(`id`),
	CONSTRAINT `service_requests_publicCode_unique` UNIQUE(`publicCode`)
);
--> statement-breakpoint
CREATE TABLE `services` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	CONSTRAINT `services_id` PRIMARY KEY(`id`),
	CONSTRAINT `services_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `technician_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`bio` text,
	`verificationStatus` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
	`averageRating` decimal(3,2) NOT NULL DEFAULT '0.00',
	`completedJobs` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `technician_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `technician_profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `technician_provinces` (
	`technicianId` int NOT NULL,
	`provinceId` int NOT NULL,
	CONSTRAINT `technician_provinces_technicianId_provinceId_pk` PRIMARY KEY(`technicianId`,`provinceId`)
);
--> statement-breakpoint
CREATE TABLE `technician_services` (
	`technicianId` int NOT NULL,
	`serviceId` int NOT NULL,
	CONSTRAINT `technician_services_technicianId_serviceId_pk` PRIMARY KEY(`technicianId`,`serviceId`)
);
--> statement-breakpoint
CREATE TABLE `wallet_ledger` (
	`id` int AUTO_INCREMENT NOT NULL,
	`technicianId` int NOT NULL,
	`requestId` int,
	`entryType` enum('commission_due','payment','prepaid_credit','adjustment') NOT NULL,
	`amount` int NOT NULL,
	`note` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wallet_ledger_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wallets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`technicianId` int NOT NULL,
	`balanceDue` int NOT NULL DEFAULT 0,
	`prepaidBalance` int NOT NULL DEFAULT 0,
	`isFrozen` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wallets_id` PRIMARY KEY(`id`),
	CONSTRAINT `wallets_technicianId_unique` UNIQUE(`technicianId`)
);
--> statement-breakpoint
CREATE TABLE `work_albums` (
	`id` int AUTO_INCREMENT NOT NULL,
	`technicianId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `work_albums_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `work_photos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`albumId` int NOT NULL,
	`photoType` enum('before','after','general') NOT NULL DEFAULT 'general',
	`storageKey` varchar(512) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `work_photos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `openId` varchar(128) NOT NULL;
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('homeowner','technician','admin') NOT NULL DEFAULT 'homeowner';
--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(32);
