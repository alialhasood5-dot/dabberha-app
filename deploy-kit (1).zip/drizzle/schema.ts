import { decimal, int, mysqlEnum, mysqlTable, primaryKey, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 128 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["homeowner", "technician", "admin"]).default("homeowner").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const adminAccounts = mysqlTable("admin_accounts", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 256 }).notNull(),
  passwordSalt: varchar("passwordSalt", { length: 128 }).notNull(),
  failedAttempts: int("failedAttempts").default(0).notNull(),
  lockedUntil: timestamp("lockedUntil"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastLoginAt: timestamp("lastLoginAt"),
});

export const provinces = mysqlTable("provinces", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  isActive: int("isActive").default(1).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
});

export const services = mysqlTable("services", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull().unique(),
  isActive: int("isActive").default(1).notNull(),
});

export const technicianProfiles = mysqlTable("technician_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  bio: text("bio"),
  verificationStatus: mysqlEnum("verificationStatus", ["pending", "verified", "rejected"]).default("pending").notNull(),
  averageRating: decimal("averageRating", { precision: 3, scale: 2 }).default("0.00").notNull(),
  completedJobs: int("completedJobs").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const technicianProvinces = mysqlTable("technician_provinces", {
  technicianId: int("technicianId").notNull(),
  provinceId: int("provinceId").notNull(),
}, (table) => ({ primaryKey: primaryKey({ columns: [table.technicianId, table.provinceId] }) }));

export const technicianServices = mysqlTable("technician_services", {
  technicianId: int("technicianId").notNull(),
  serviceId: int("serviceId").notNull(),
}, (table) => ({ primaryKey: primaryKey({ columns: [table.technicianId, table.serviceId] }) }));

export const serviceRequests = mysqlTable("service_requests", {
  id: int("id").autoincrement().primaryKey(),
  publicCode: varchar("publicCode", { length: 24 }).notNull().unique(),
  homeownerId: int("homeownerId").notNull(),
  provinceId: int("provinceId").notNull(),
  serviceId: int("serviceId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description").notNull(),
  budgetMin: int("budgetMin"),
  budgetMax: int("budgetMax"),
  status: mysqlEnum("status", ["open", "assigned", "in_progress", "awaiting_confirmation", "completed", "cancelled"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const offers = mysqlTable("offers", {
  id: int("id").autoincrement().primaryKey(),
  requestId: int("requestId").notNull(),
  technicianId: int("technicianId").notNull(),
  amount: int("amount").notNull(),
  note: text("note"),
  status: mysqlEnum("status", ["pending", "accepted", "rejected", "withdrawn"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const ratings = mysqlTable("ratings", {
  id: int("id").autoincrement().primaryKey(),
  requestId: int("requestId").notNull().unique(),
  homeownerId: int("homeownerId").notNull(),
  technicianId: int("technicianId").notNull(),
  stars: int("stars").notNull(),
  comment: text("comment"),
  isHidden: int("isHidden").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const workAlbums = mysqlTable("work_albums", {
  id: int("id").autoincrement().primaryKey(),
  technicianId: int("technicianId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const workPhotos = mysqlTable("work_photos", {
  id: int("id").autoincrement().primaryKey(),
  albumId: int("albumId").notNull(),
  photoType: mysqlEnum("photoType", ["before", "after", "general"]).default("general").notNull(),
  storageKey: varchar("storageKey", { length: 512 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const wallets = mysqlTable("wallets", {
  id: int("id").autoincrement().primaryKey(),
  technicianId: int("technicianId").notNull().unique(),
  balanceDue: int("balanceDue").default(0).notNull(),
  prepaidBalance: int("prepaidBalance").default(0).notNull(),
  isFrozen: int("isFrozen").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const walletLedger = mysqlTable("wallet_ledger", {
  id: int("id").autoincrement().primaryKey(),
  technicianId: int("technicianId").notNull(),
  requestId: int("requestId"),
  entryType: mysqlEnum("entryType", ["commission_due", "payment", "prepaid_credit", "adjustment"]).notNull(),
  amount: int("amount").notNull(),
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const commissionSettings = mysqlTable("commission_settings", {
  id: int("id").autoincrement().primaryKey(),
  ratePercent: decimal("ratePercent", { precision: 5, scale: 2 }).default("10.00").notNull(),
  collectionMethod: varchar("collectionMethod", { length: 80 }).default("زين كاش").notNull(),
  freeLaunchUntil: timestamp("freeLaunchUntil"),
  freezeThreshold: int("freezeThreshold").default(100000).notNull(),
  updatedByAdminId: int("updatedByAdminId").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type AdminAccount = typeof adminAccounts.$inferSelect;
export type Province = typeof provinces.$inferSelect;
export type Service = typeof services.$inferSelect;
export type TechnicianProfile = typeof technicianProfiles.$inferSelect;
