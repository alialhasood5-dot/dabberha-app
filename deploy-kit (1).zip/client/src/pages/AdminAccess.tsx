import { useEffect, useState } from "react";
import { ArrowRight, CheckCircle2, Eye, EyeOff, LockKeyhole, ShieldCheck } from "lucide-react";
import { Link, useLocation } from "wouter";

const ADMIN_EMAIL = "alialhasood5@gmail.com";

export default function AdminAccess({ mode }: { mode: "setup" | "login" }) {
  const [, navigate] = useLocation();
  const [email, setEmail] = useState(ADMIN_EMAIL);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [setupComplete, setSetupComplete] = useState(false);

  useEffect(() => {
    fetch("/api/admin/setup-status", { credentials: "include" }).then((r) => r.json()).then((data) => setSetupComplete(Boolean(data.setupComplete))).catch(() => undefined);
  }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault(); setError("");
    if (mode === "setup" && password !== confirm) { setError("كلمتا المرور غير متطابقتين"); return; }
    setLoading(true);
    try {
      const response = await fetch(mode === "setup" ? "/api/admin/setup" : "/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ email, password }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "تعذر إكمال العملية");
      navigate("/admin");
    } catch (err) { setError(err instanceof Error ? err.message : "تعذر إكمال العملية"); }
    finally { setLoading(false); }
  }

  return <main className="flex min-h-screen items-center justify-center bg-[#f5f6f1] px-4 py-10" dir="rtl"><div className="w-full max-w-md"><div className="mb-7 flex items-center justify-center gap-3"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#24433b] text-[#f5e7c8]"><LockKeyhole size={23} /></div><div><div className="text-2xl font-black text-[#24433b]">دبّرها</div><div className="text-xs text-[#87938a]">بوابة المشرف الآمنة</div></div></div><div className="rounded-3xl border border-[#e6ebe4] bg-white p-7 shadow-[0_20px_60px_rgba(35,61,48,.09)]"><div className="flex items-start gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e4f1e8] text-[#237650]"><ShieldCheck size={20} /></div><div><div className="text-lg font-black text-[#294238]">{mode === "setup" ? "تعيين كلمة مرور المشرف" : "تسجيل دخول المشرف"}</div><p className="mt-1 text-xs leading-6 text-[#89958c]">{mode === "setup" ? "عيّن كلمة مرور قوية بنفسك. لا ترسلها لأي شخص ولا تضعها في GitHub." : "أدخل بيانات المشرف للوصول إلى لوحة التحكم."}</p></div></div><form onSubmit={submit} className="mt-6 space-y-4"><label className="field-label">البريد الإلكتروني<input className="field-input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label><label className="field-label">كلمة المرور<div className="relative"><input className="field-input pl-11" type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} minLength={12} required placeholder="12 حرفاً على الأقل" /><button type="button" className="absolute left-2 top-1/2 -translate-y-1/2 border-0 bg-transparent p-2 text-[#87958b]" onClick={() => setShowPassword((value) => !value)}>{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button></div></label>{mode === "setup" && <label className="field-label">تأكيد كلمة المرور<input className="field-input" type={showPassword ? "text" : "password"} value={confirm} onChange={(e) => setConfirm(e.target.value)} minLength={12} required /></label>}{error && <div className="rounded-xl bg-[#fff0ef] px-3 py-2 text-xs font-bold leading-5 text-[#a44d49]">{error}</div>}<button className="primary-button h-12 w-full" disabled={loading}>{loading ? "جارٍ المعالجة..." : mode === "setup" ? "حفظ كلمة المرور والدخول" : "دخول آمن"}<ArrowRight size={16} /></button></form>{mode === "setup" && <div className="mt-4 flex items-start gap-2 rounded-xl bg-[#f3f7f1] p-3 text-[11px] leading-5 text-[#6f8073]"><CheckCircle2 size={15} className="mt-0.5 shrink-0 text-[#2c8660]" /> كلمة المرور تُخزّن كقيمة مشفّرة فقط، مع إيقاف مؤقت بعد محاولات الدخول الفاشلة.</div>}<div className="mt-6 border-t border-[#edf0eb] pt-4 text-center text-xs text-[#8d9990]">{mode === "setup" ? <>{setupComplete ? "تم إعداد الحساب مسبقاً. " : "لديك حساب بالفعل؟ "}<Link href="/admin/login" className="font-bold text-[#2c8660]">تسجيل الدخول</Link></> : <>لا يوجد حساب بعد؟ <Link href="/admin/setup" className="font-bold text-[#2c8660]">إنشاء كلمة المرور</Link></>}</div></div></div></main>;
}
