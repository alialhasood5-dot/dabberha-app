import { useMemo, useState } from "react";
import {
  Bell,
  BriefcaseBusiness,
  Check,
  ChevronLeft,
  ChevronDown,
  ClipboardList,
  Clock3,
  Coins,
  FileCheck2,
  Home as HomeIcon,
  ImagePlus,
  MapPin,
  Menu,
  MessageCircle,
  MoreHorizontal,
  Plus,
  Search,
  Send,
  ShieldCheck,
  SlidersHorizontal,
  Star,
  ThumbsUp,
  UserRound,
  UsersRound,
  Wrench,
  X,
} from "lucide-react";

type Role = "homeowner" | "technician" | "admin";
type Tab = "home" | "requests" | "technicians" | "messages" | "profile";

type Technician = {
  id: number;
  name: string;
  trade: string;
  city: string;
  rating: string;
  jobs: number;
  verified: boolean;
  image: string;
  accent: string;
};

const provinces = ["بغداد", "البصرة", "نينوى", "أربيل", "النجف", "كربلاء", "ذي قار", "الأنبار", "ديالى", "بابل", "كركوك", "واسط", "صلاح الدين", "ميسان", "المثنى", "القادسية", "دهوك", "السليمانية"];
const services = ["كهرباء", "تكييف وتبريد", "سباكة ومجاري", "بناء وترميم", "صبغ وديكور", "نجارة", "تنظيف"];

const technicians: Technician[] = [
  { id: 1, name: "علي كريم", trade: "صيانة تكييف وتبريد", city: "بغداد · الكرخ", rating: "4.9", jobs: 126, verified: true, image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=160&q=80", accent: "#e8f0e8" },
  { id: 2, name: "محمد عبد الستار", trade: "كهرباء منزلية", city: "بغداد · الرصافة", rating: "4.8", jobs: 84, verified: true, image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=160&q=80", accent: "#f4ead5" },
  { id: 3, name: "حسن فاضل", trade: "سباكة ومجاري", city: "بغداد · المنصور", rating: "4.7", jobs: 57, verified: false, image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=160&q=80", accent: "#e6eef0" },
];

const requests = [
  { id: "DB-1042", title: "صيانة سبلت غرفة النوم", service: "تكييف وتبريد", location: "بغداد · الكرخ", status: "بانتظار العروض", statusColor: "amber", time: "منذ 18 دقيقة", offers: 3 },
  { id: "DB-1038", title: "تسريب ماء في المطبخ", service: "سباكة ومجاري", location: "بغداد · اليرموك", status: "تم اختيار الفني", statusColor: "green", time: "أمس", offers: 5 },
  { id: "DB-1029", title: "تبديل قواطع الكهرباء", service: "كهرباء", location: "بغداد · زيونة", status: "مغلق ومقيّم", statusColor: "slate", time: "قبل 4 أيام", offers: 2 },
];

function Badge({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "verified" | "amber" | "green" | "slate" }) {
  const tones = {
    neutral: "bg-[#f2f0e9] text-[#5d665e]",
    verified: "bg-[#e4f1e8] text-[#176847]",
    amber: "bg-[#fff1d6] text-[#98661c]",
    green: "bg-[#e4f1e8] text-[#176847]",
    slate: "bg-[#eef0f1] text-[#5f6c71]",
  };
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold ${tones[tone]}`}>{children}</span>;
}

function StatCard({ icon: Icon, label, value, note, tone }: { icon: typeof ClipboardList; label: string; value: string; note: string; tone: string }) {
  return (
    <div className="stat-card">
      <div className={`stat-icon ${tone}`}><Icon size={19} strokeWidth={2.2} /></div>
      <div className="min-w-0">
        <div className="text-[12px] font-medium text-[#77817a]">{label}</div>
        <div className="mt-0.5 text-[23px] font-black tracking-tight text-[#263e36]">{value}</div>
        <div className="mt-0.5 text-[11px] text-[#87918a]">{note}</div>
      </div>
    </div>
  );
}

function TechnicianCard({ tech, onView }: { tech: Technician; onView: (tech: Technician) => void }) {
  return (
    <button onClick={() => onView(tech)} className="tech-card group text-right">
      <div className="flex items-start justify-between gap-3">
        <div className="relative">
          <img src={tech.image} alt={tech.name} className="h-14 w-14 rounded-2xl object-cover ring-4 ring-white shadow-sm" />
          {tech.verified && <span className="absolute -bottom-1 -left-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-white bg-[#2e8b68] text-white"><Check size={11} strokeWidth={3} /></span>}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-1.5">
            <h3 className="font-bold text-[#29423a]">{tech.name}</h3>
            {tech.verified && <ShieldCheck size={15} className="text-[#27845d]" />}
          </div>
          <p className="mt-1 text-xs text-[#748079]">{tech.trade}</p>
          <p className="mt-1 flex items-center gap-1 text-[11px] text-[#99a19c]"><MapPin size={11} /> {tech.city}</p>
        </div>
        <ChevronLeft size={18} className="mt-1 text-[#aab3ad] transition group-hover:-translate-x-1" />
      </div>
      <div className="mt-4 flex items-center justify-between border-t border-[#edf0ea] pt-3">
        <div className="flex items-center gap-1 text-sm font-bold text-[#374940]"><Star size={14} className="fill-[#e5a13b] text-[#e5a13b]" /> {tech.rating} <span className="text-[11px] font-normal text-[#9aa49e]">({tech.jobs} عمل)</span></div>
        <span className="text-[11px] font-bold text-[#2c8660]">عرض الملف</span>
      </div>
    </button>
  );
}

function NewRequestModal({ onClose, onCreate }: { onClose: () => void; onCreate: () => void }) {
  const [service, setService] = useState("تكييف وتبريد");
  const [province, setProvince] = useState("بغداد");
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div className="modal-panel" onMouseDown={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between">
          <div><div className="eyebrow">طلب جديد</div><h2 className="mt-1 text-2xl font-black text-[#28423a]">ما الخدمة التي تحتاجها؟</h2><p className="mt-1 text-sm text-[#7f8982]">سيصل طلبك إلى الفنيين القريبين منك فقط.</p></div>
          <button className="icon-button" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="mt-6 space-y-4">
          <label className="field-label">نوع الخدمة<select value={service} onChange={(e) => setService(e.target.value)} className="field-input">{services.map((item) => <option key={item}>{item}</option>)}</select></label>
          <label className="field-label">المحافظة<select value={province} onChange={(e) => setProvince(e.target.value)} className="field-input">{provinces.map((item) => <option key={item}>{item}</option>)}</select></label>
          <label className="field-label">اشرح المشكلة<textarea className="field-input min-h-[105px] resize-none" placeholder="مثال: السبلت يشتغل لكن لا يبرد..." /></label>
          <label className="field-label">الميزانية المتوقعة <span className="font-normal text-[#9aa39d]">(اختياري)</span><input className="field-input" placeholder="مثال: 50,000 د.ع" /></label>
        </div>
        <div className="mt-6 flex gap-3"><button className="secondary-button flex-1" onClick={onClose}>إلغاء</button><button className="primary-button flex-[2]" onClick={onCreate}><Send size={16} /> نشر الطلب</button></div>
      </div>
    </div>
  );
}

function TechProfileModal({ tech, onClose }: { tech: Technician; onClose: () => void }) {
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div className="modal-panel max-w-lg" onMouseDown={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between"><div className="flex items-center gap-3"><img src={tech.image} alt={tech.name} className="h-16 w-16 rounded-2xl object-cover" /><div><div className="flex items-center gap-1.5"><h2 className="text-xl font-black text-[#28423a]">{tech.name}</h2>{tech.verified && <ShieldCheck size={17} className="text-[#27845d]" />}</div><p className="mt-1 text-sm text-[#7d8880]">{tech.trade}</p><p className="mt-1 flex items-center gap-1 text-xs text-[#9aa39d]"><MapPin size={12} /> {tech.city}</p></div></div><button className="icon-button" onClick={onClose}><X size={18} /></button></div>
        <div className="mt-5 flex gap-2"><Badge tone={tech.verified ? "verified" : "neutral"}>{tech.verified ? "فني موثّق" : "لم يكتمل التوثيق"}</Badge><Badge><Star size={12} className="fill-[#e5a13b] text-[#e5a13b]" /> {tech.rating} تقييم</Badge><Badge>{tech.jobs} عمل مكتمل</Badge></div>
        <div className="mt-6"><div className="flex items-center justify-between"><h3 className="font-black text-[#344c42]">ألبوم الأعمال</h3><span className="text-xs text-[#849088]">قبل وبعد</span></div><div className="mt-3 grid grid-cols-3 gap-2"><div className="album-photo bg-[#d4e1d8]"><Wrench size={22} /><span>صيانة سبلت</span></div><div className="album-photo bg-[#eadcc4]"><HomeIcon size={22} /><span>تركيب جديد</span></div><div className="album-photo bg-[#d9e4e9]"><BriefcaseBusiness size={22} /><span>عمل مكتمل</span></div></div></div>
        <button className="primary-button mt-6 w-full"><MessageCircle size={17} /> مراسلة الفني بعد تقديم العرض</button>
      </div>
    </div>
  );
}

function RequestComposer({ onCreate }: { onCreate: () => void }) {
  return <div className="request-composer"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#edf4ed] text-[#31805c]"><Plus size={21} /></div><div className="flex-1 text-right"><div className="font-bold text-[#345046]">تحتاج فني؟ ابدأ طلبك هنا</div><div className="mt-1 text-xs text-[#8b968e]">اختر الخدمة والمحافظة وسيصلك أفضل العروض</div></div><button className="primary-button !px-4" onClick={onCreate}>طلب جديد</button></div>;
}

function HomeDashboard({ onNewRequest, onViewTech }: { onNewRequest: () => void; onViewTech: (tech: Technician) => void }) {
  return <>
    <section className="hero-card"><div className="relative z-10 max-w-xl"><div className="eyebrow text-[#bed4c1]">خدمات بيتك أسهل</div><h1 className="mt-2 text-3xl font-black leading-tight text-white sm:text-[38px]">خلي شغلك علينا،<br /><span className="text-[#e9bd70]">والفني الموثوق علينا.</span></h1><p className="mt-4 max-w-md text-sm leading-7 text-[#d4e0d6]">اطلب خدمتك من فنيين قريبين منك، شوف أعمالهم، وتابع كل شيء من مكان واحد.</p><button className="gold-button mt-6" onClick={onNewRequest}><Plus size={17} /> ابدأ طلب جديد</button></div><div className="hero-art"><div className="hero-ring" /><Wrench size={74} strokeWidth={1.2} /></div></section>
    <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4"><StatCard icon={ClipboardList} label="طلباتك الحالية" value="2" note="طلب يحتاج متابعة" tone="olive" /><StatCard icon={Clock3} label="بانتظار العروض" value="1" note="سيصلك إشعار قريباً" tone="gold" /><StatCard icon={MessageCircle} label="رسائل جديدة" value="4" note="من فنيين مهتمين" tone="blue" /><StatCard icon={ThumbsUp} label="أعمال مكتملة" value="8" note="كلها بتقييم جيد" tone="green" /></div>
    <div className="mt-8 grid gap-6 xl:grid-cols-[1.2fr_0.8fr]"><div><div className="section-heading"><div><div className="eyebrow">نشاطك الأخير</div><h2>طلبات تحتاج انتباهك</h2></div><button className="text-button">عرض الكل <ChevronLeft size={15} /></button></div><div className="mt-4 space-y-3">{requests.map((request) => <div key={request.id} className="request-row"><div className="request-dot"><Wrench size={17} /></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h3 className="truncate font-bold text-[#30473e]">{request.title}</h3><Badge tone={request.statusColor as "amber" | "green" | "slate"}>{request.status}</Badge></div><div className="mt-2 flex flex-wrap items-center gap-3 text-[11px] text-[#8a958e]"><span>{request.id}</span><span>•</span><span>{request.location}</span><span>•</span><span>{request.time}</span></div></div><div className="hidden text-left sm:block"><div className="text-xs font-bold text-[#3b5148]">{request.offers} عروض</div><div className="mt-1 text-[10px] text-[#9aa39d]">وصلت إليك</div></div><ChevronLeft size={18} className="text-[#aab3ad]" /></div>)}</div></div><div><div className="section-heading"><div><div className="eyebrow">مختارون لك</div><h2>فنيون موثوقون بالقرب منك</h2></div><button className="icon-button"><SlidersHorizontal size={16} /></button></div><div className="mt-4 space-y-3">{technicians.slice(0, 2).map((tech) => <TechnicianCard key={tech.id} tech={tech} onView={onViewTech} />)}</div></div></div>
    <div className="mt-8"><RequestComposer onCreate={onNewRequest} /></div>
  </>;
}

function TechnicianWorkspace({ onViewTech }: { onViewTech: (tech: Technician) => void }) {
  return <><div className="workspace-banner"><div><div className="eyebrow text-[#c6d9c9]">مساحتك المهنية</div><h1 className="mt-2 text-3xl font-black text-white">أهلاً بك يا علي، <span className="text-[#e9bd70]">شغلك يحكي عنك.</span></h1><p className="mt-3 text-sm leading-7 text-[#d4e0d6]">أكمل ملفك وأضف صور أعمالك حتى يظهر اسمك لأصحاب البيوت القريبين منك.</p></div><div className="profile-score"><div className="text-3xl font-black">78%</div><div className="mt-1 text-xs text-[#d7e6d8]">اكتمال الملف</div><div className="mt-3 h-1.5 w-28 overflow-hidden rounded-full bg-white/15"><div className="h-full w-[78%] rounded-full bg-[#e9bd70]" /></div></div></div><div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4"><StatCard icon={ClipboardList} label="طلبات جديدة" value="12" note="في محافظتك" tone="olive" /><StatCard icon={Coins} label="الرصيد المستحق" value="245K" note="د.ع · قابل للسداد" tone="gold" /><StatCard icon={Star} label="متوسط التقييم" value="4.8" note="من 37 تقييماً" tone="blue" /><StatCard icon={ImagePlus} label="صور الألبوم" value="18" note="يمكنك إضافة المزيد" tone="green" /></div><div className="mt-8 grid gap-6 xl:grid-cols-[1.15fr_0.85fr]"><div><div className="section-heading"><div><div className="eyebrow">طلبات قريبة</div><h2>طلبات تناسب خدماتك</h2></div><button className="text-button">تصفية <SlidersHorizontal size={14} /></button></div><div className="mt-4 space-y-3">{[{title:"تبديل لوحة كهرباء", service:"كهرباء", location:"بغداد · زيونة", budget:"50,000 – 75,000 د.ع", time:"منذ 8 دقائق"},{title:"تنظيف وصيانة سبلت", service:"تكييف وتبريد", location:"بغداد · الكرادة", budget:"25,000 – 40,000 د.ع", time:"منذ 22 دقيقة"},{title:"إصلاح تسرب في الحمام", service:"سباكة ومجاري", location:"بغداد · حي الجامعة", budget:"30,000 د.ع", time:"منذ ساعة"}].map((item) => <div key={item.title} className="job-row"><div className="request-dot"><Wrench size={17} /></div><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><h3 className="font-bold text-[#30473e]">{item.title}</h3><Badge>{item.service}</Badge></div><div className="mt-2 flex flex-wrap gap-3 text-[11px] text-[#8a958e]"><span><MapPin size={11} className="inline" /> {item.location}</span><span>{item.time}</span></div></div><div className="hidden text-left sm:block"><div className="text-xs font-bold text-[#4e6157]">{item.budget}</div><button className="mt-2 text-[11px] font-bold text-[#2c8660]">تقديم عرض</button></div><ChevronLeft size={18} className="text-[#aab3ad]" /></div>)}</div></div><div><div className="section-heading"><div><div className="eyebrow">ملفك</div><h2>ألبوم أعمالك</h2></div><button className="icon-button"><MoreHorizontal size={17} /></button></div><div className="album-grid mt-4"><div className="album-photo bg-[#d7e4d8]"><Wrench size={25} /><span>تركيب سبلت</span></div><div className="album-photo bg-[#eadcc4]"><HomeIcon size={25} /><span>قبل / بعد</span></div><div className="album-photo bg-[#d7e2e6]"><ImagePlus size={24} /><span>إضافة صورة</span></div></div><div className="mt-5 rounded-2xl border border-[#e8ece6] bg-white p-4"><div className="flex items-start gap-3"><ShieldCheck size={21} className="mt-0.5 text-[#2b8962]" /><div><div className="font-bold text-[#3b5147]">اجعل ملفك موثّقاً</div><p className="mt-1 text-xs leading-6 text-[#89938c]">أرسل مستمسكاتك للمشرف لتحصل على شارة تزيد ثقة أصحاب البيوت بك.</p><button className="mt-3 text-xs font-bold text-[#2c8660]">طلب التوثيق <ChevronLeft size={13} className="inline" /></button></div></div></div></div></div></>;
}

function AdminWorkspace() {
  return <><div className="admin-banner"><div><div className="eyebrow text-[#c6d9c9]">لوحة المشرف</div><h1 className="mt-2 text-3xl font-black text-white">صباح الخير، مدير دبّرها.</h1><p className="mt-3 text-sm text-[#d4e0d6]">هذه نظرة سريعة على ما يحدث في المنصة اليوم.</p></div><div className="admin-date">29 أكتوبر<br /><span>2026</span></div></div><div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4"><StatCard icon={UsersRound} label="إجمالي المستخدمين" value="1,284" note="+12% هذا الشهر" tone="olive" /><StatCard icon={Wrench} label="فنيون بانتظار التوثيق" value="18" note="يحتاجون مراجعة" tone="gold" /><StatCard icon={Coins} label="عمولات مستحقة" value="1.84M" note="دينار عراقي" tone="blue" /><StatCard icon={MessageCircle} label="بلاغات مفتوحة" value="7" note="تحتاج متابعة" tone="green" /></div><div className="mt-8 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]"><div className="panel-card"><div className="section-heading"><div><div className="eyebrow">تحتاج إجراء</div><h2>آخر طلبات التوثيق</h2></div><button className="text-button">كل الطلبات <ChevronLeft size={15} /></button></div><div className="mt-4 space-y-1">{technicians.map((tech, index) => <div key={tech.id} className="admin-row"><img src={tech.image} alt="" className="h-10 w-10 rounded-xl object-cover" /><div className="min-w-0 flex-1"><div className="font-bold text-[#3a5046]">{tech.name}</div><div className="mt-1 text-[11px] text-[#929d95]">طلب توثيق · {index + 1} {index === 0 ? "ساعة" : "يوم"}</div></div><button className="small-action">مراجعة</button></div>)}</div></div><div className="panel-card"><div className="section-heading"><div><div className="eyebrow">إعدادات الإيرادات</div><h2>العمولة الحالية</h2></div><button className="icon-button"><MoreHorizontal size={17} /></button></div><div className="mt-6 flex items-end gap-3"><div className="text-5xl font-black tracking-tight text-[#28423a]">10<span className="text-2xl">%</span></div><Badge tone="green">نشطة بعد الإطلاق</Badge></div><p className="mt-3 text-sm leading-7 text-[#849087]">فترة الإطلاق المجانية تنتهي في <strong className="text-[#475b51]">31 يناير 2027</strong>. لا يتم احتساب أي عمولة قبلها.</p><div className="mt-5 h-2 overflow-hidden rounded-full bg-[#edf0e9]"><div className="h-full w-[42%] rounded-full bg-[#d99b44]" /></div><div className="mt-2 flex justify-between text-[11px] text-[#97a19a]"><span>بداية الإطلاق</span><span>42% من الفترة</span></div><button className="secondary-button mt-6 w-full"><SlidersHorizontal size={15} /> تعديل الإعدادات</button></div></div></>;
}

function RequestsView({ role, onNewRequest }: { role: Role; onNewRequest: () => void }) {
  const rows = role === "technician"
    ? ["تبديل لوحة كهرباء", "تنظيف وصيانة سبلت", "إصلاح تسرب في الحمام", "تركيب سخان ماء"]
    : ["صيانة سبلت غرفة النوم", "تسريب ماء في المطبخ", "تبديل قواطع الكهرباء"];
  return <div className="space-y-6"><div className="section-heading"><div><div className="eyebrow">{role === "technician" ? "طلبات ضمن محافظتك" : "سجل الخدمات"}</div><h2 className="!text-2xl">{role === "technician" ? "اختر عملاً يناسبك" : "كل طلباتك في مكان واحد"}</h2></div>{role === "homeowner" && <button className="primary-button" onClick={onNewRequest}><Plus size={16} /> طلب جديد</button>}</div><div className="flex flex-wrap gap-2"><Badge tone="green">الكل · {rows.length}</Badge><Badge tone="amber">قيد المتابعة · 2</Badge><Badge>مكتملة · 1</Badge></div><div className="space-y-3">{rows.map((title, index) => <div className="job-row" key={title}><div className="request-dot"><Wrench size={17} /></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h3 className="font-bold text-[#30473e]">{title}</h3><Badge tone={index === 0 ? "amber" : index === 1 ? "green" : "slate"}>{index === 0 ? "قيد المتابعة" : index === 1 ? "تم اختيار الفني" : "مكتمل"}</Badge></div><div className="mt-2 flex flex-wrap gap-3 text-[11px] text-[#8a958e]"><span><MapPin size={11} className="inline" /> بغداد · {index % 2 === 0 ? "الكرخ" : "الرصافة"}</span><span>DB-10{42 - index}</span><span>{index + 1} عروض</span></div></div><div className="text-left"><div className="text-xs font-bold text-[#4f6158]">{index === 2 ? "مغلق" : "منذ ساعتين"}</div><ChevronLeft size={18} className="mt-2 mr-auto text-[#aab3ad]" /></div></div>)}</div></div>;
}

function MessagesView() {
  const chats = [{ name: "علي كريم", text: "أهلاً، شفت طلبك وأقدر أجي اليوم...", time: "10:42", unread: 2 }, { name: "محمد عبد الستار", text: "أرسلت لك تفاصيل العرض والصور", time: "أمس", unread: 0 }, { name: "دعم دبّرها", text: "تم تحديث حالة طلبك DB-1038", time: "أمس", unread: 1 }];
  return <div className="space-y-6"><div className="section-heading"><div><div className="eyebrow">تواصل آمن داخل التطبيق</div><h2 className="!text-2xl">المحادثات</h2></div><Badge tone="verified"><ShieldCheck size={12} /> أرقام الهاتف مخفية</Badge></div><div className="grid gap-5 lg:grid-cols-[.8fr_1.2fr]"><div className="panel-card p-2"><div className="mb-2 flex items-center gap-2 px-3 py-2 text-xs text-[#95a098]"><Search size={14} /><span>ابحث في المحادثات</span></div>{chats.map((chat, index) => <button key={chat.name} className={`flex w-full items-center gap-3 rounded-xl p-3 text-right ${index === 0 ? "bg-[#edf4ed]" : "hover:bg-[#f5f7f3]"}`}><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#dcebdd] font-black text-[#3c7756]">{chat.name.slice(0, 1)}</div><div className="min-w-0 flex-1"><div className="flex justify-between gap-2"><div className="font-bold text-[#40564b]">{chat.name}</div><span className="text-[10px] text-[#9aa49d]">{chat.time}</span></div><div className="mt-1 truncate text-[11px] text-[#89958c]">{chat.text}</div></div>{chat.unread > 0 && <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#d99b4b] px-1.5 text-[10px] font-bold text-white">{chat.unread}</span>}</button>)}</div><div className="panel-card flex min-h-[300px] flex-col"><div className="flex items-center gap-3 border-b border-[#edf0eb] pb-4"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#dcebdd] font-black text-[#3c7756]">ع</div><div><div className="font-bold text-[#40564b]">علي كريم</div><div className="mt-1 text-[11px] text-[#2c8660]">متصل الآن · فني موثّق</div></div><button className="icon-button mr-auto"><MoreHorizontal size={17} /></button></div><div className="flex flex-1 flex-col justify-end gap-3 py-5"><div className="w-fit max-w-[80%] rounded-2xl rounded-bl-sm bg-[#edf4ed] px-4 py-3 text-xs leading-6 text-[#506259]">أهلاً، شفت طلبك وأقدر أجي اليوم بعد الساعة 5. أرسل لك صور أعمالي؟<div className="mt-1 text-[10px] text-[#9ba69e]">10:42 ص</div></div><div className="mr-auto w-fit max-w-[80%] rounded-2xl rounded-br-sm bg-[#2c7d5b] px-4 py-3 text-xs leading-6 text-white">نعم، أرسلها لو سمحت. وهل يشمل العرض تبديل الفلتر؟<div className="mt-1 text-[10px] text-[#d5ead9]">10:44 ص</div></div></div><div className="flex items-center gap-2 border-t border-[#edf0eb] pt-4"><button className="icon-button"><ImagePlus size={16} /></button><input className="field-input" placeholder="اكتب رسالتك هنا..." /><button className="primary-button !h-10 !w-10 !p-0"><Send size={15} /></button></div></div></div></div>;
}

function DirectoryView({ onViewTech }: { onViewTech: (tech: Technician) => void }) {
  return <div className="space-y-6"><div className="section-heading"><div><div className="eyebrow">اختيارك يبدأ من المكان</div><h2 className="!text-2xl">فنيون حسب المحافظة والخدمة</h2></div><button className="secondary-button"><SlidersHorizontal size={15} /> تصفية</button></div><div className="flex flex-wrap gap-2"><Badge tone="green"><MapPin size={12} /> بغداد</Badge>{services.slice(0, 4).map((service) => <Badge key={service}>{service}</Badge>)}</div><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{technicians.map((tech) => <TechnicianCard key={tech.id} tech={tech} onView={onViewTech} />)}</div></div>;
}

function ProfileView({ role }: { role: Role }) {
  if (role === "admin") return <div className="space-y-6"><div><div className="eyebrow">إدارة المنصة</div><h2 className="mt-1 text-2xl font-black text-[#30483d]">الإعدادات والصلاحيات</h2></div><div className="grid gap-4 md:grid-cols-2"><div className="panel-card"><div className="flex items-center gap-3"><div className="help-orb"><SlidersHorizontal size={18} /></div><div><div className="font-bold text-[#40564b]">إعدادات العمولة</div><div className="mt-1 text-xs text-[#8b968e]">النسبة، مدة الإطلاق، وحد التجميد</div></div></div><div className="mt-5 grid grid-cols-2 gap-3"><label className="field-label">النسبة<input className="field-input" value="10%" readOnly /></label><label className="field-label">الوسيلة<select className="field-input" defaultValue="زين كاش"><option>زين كاش</option><option>تحويل مصرفي</option><option>رصيد مسبق</option></select></label></div><button className="primary-button mt-5 w-full">حفظ التغييرات</button></div><div className="panel-card"><div className="flex items-center gap-3"><div className="help-orb"><ShieldCheck size={18} /></div><div><div className="font-bold text-[#40564b]">طلبات التوثيق</div><div className="mt-1 text-xs text-[#8b968e]">18 فني بانتظار المراجعة</div></div></div><button className="secondary-button mt-5 w-full">فتح قائمة المراجعة</button></div></div><div className="panel-card"><div className="flex items-center gap-3"><FileCheck2 size={19} className="text-[#3a7b59]" /><div><div className="font-bold text-[#40564b]">الشروط وسياسة الخصوصية</div><div className="mt-1 text-xs text-[#8b968e]">آخر تحديث: 29 أكتوبر 2026</div></div><button className="text-button mr-auto">تعديل <ChevronLeft size={14} /></button></div></div></div>;
  return <div className="space-y-6"><div><div className="eyebrow">حسابك في دبّرها</div><h2 className="mt-1 text-2xl font-black text-[#30483d]">الملف والإعدادات</h2></div><div className="panel-card flex items-center gap-4"><div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#bd8b59] text-2xl font-black text-white">ع</div><div><div className="text-lg font-black text-[#30483d]">علي حسن</div><div className="mt-1 text-xs text-[#8b968e]">{role === "technician" ? "فني · بغداد" : "صاحب بيت · بغداد"}</div><button className="mt-2 text-xs font-bold text-[#2c8660]">تعديل الملف</button></div><button className="icon-button mr-auto"><MoreHorizontal size={17} /></button></div><div className="panel-card space-y-4"><div className="flex items-center justify-between"><span className="text-sm font-bold text-[#465c50]">الإشعارات</span><div className="h-6 w-10 rounded-full bg-[#2c7d5b] p-1"><div className="mr-auto h-4 w-4 rounded-full bg-white" /></div></div><div className="flex items-center justify-between border-t border-[#edf0eb] pt-4"><span className="text-sm font-bold text-[#465c50]">الشروط وسياسة الخصوصية</span><ChevronLeft size={16} className="text-[#99a49c]" /></div></div></div>;
}

function AppHeader({ role, setRole, onNewRequest }: { role: Role; setRole: (role: Role) => void; onNewRequest: () => void }) {
  const roleLabel = role === "homeowner" ? "صاحب البيت" : role === "technician" ? "الفني" : "المشرف";
  return <header className="app-header"><div className="brand"><div className="brand-mark"><Wrench size={19} strokeWidth={2.5} /></div><div><div className="brand-name">دبّرها</div><div className="brand-sub">خدماتك بيد أمينة</div></div></div><div className="header-center"><div className="search-box"><Search size={16} /><input placeholder="ابحث عن خدمة، فني أو طلب..." /></div></div><div className="header-actions"><button className="header-icon"><Bell size={19} /><span className="notification-dot" /></button><div className="divider" /><div className="role-switch"><span className="avatar">ع</span><div className="hidden text-right sm:block"><div className="text-xs font-bold text-[#354c42]">علي حسن</div><div className="text-[10px] text-[#8d9890]">{roleLabel}</div></div><select value={role} onChange={(e) => setRole(e.target.value as Role)} className="role-select" aria-label="تبديل الدور"><option value="homeowner">صاحب البيت</option><option value="technician">الفني</option>{role === "admin" && <option value="admin">المشرف</option>}</select><ChevronDown size={14} className="text-[#859189]" /></div></div><button className="mobile-menu"><Menu size={21} /></button></header>;
}

function Sidebar({ tab, setTab, role }: { tab: Tab; setTab: (tab: Tab) => void; role: Role }) {
  const items: { id: Tab; label: string; icon: typeof HomeIcon }[] = role === "admin" ? [{ id: "home", label: "نظرة عامة", icon: HomeIcon }, { id: "requests", label: "الطلبات", icon: ClipboardList }, { id: "technicians", label: "الفنيون", icon: UsersRound }, { id: "messages", label: "البلاغات", icon: MessageCircle }, { id: "profile", label: "الإعدادات", icon: SlidersHorizontal }] : role === "technician" ? [{ id: "home", label: "مساحتي", icon: HomeIcon }, { id: "requests", label: "طلبات قريبة", icon: ClipboardList }, { id: "technicians", label: "ملف أعمالي", icon: ImagePlus }, { id: "messages", label: "المحادثات", icon: MessageCircle }, { id: "profile", label: "حسابي", icon: UserRound }] : [{ id: "home", label: "الرئيسية", icon: HomeIcon }, { id: "requests", label: "طلباتي", icon: ClipboardList }, { id: "technicians", label: "الفنيون", icon: UsersRound }, { id: "messages", label: "المحادثات", icon: MessageCircle }, { id: "profile", label: "حسابي", icon: UserRound }];
  return <aside className="sidebar"><div className="sidebar-label">القائمة الرئيسية</div>{items.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => setTab(id)} className={`nav-item ${tab === id ? "active" : ""}`}><Icon size={18} /><span>{label}</span>{id === "messages" && <span className="nav-count">4</span>}</button>)}<div className="sidebar-divider" /><div className="sidebar-label">مساعدة</div><button className="nav-item"><FileCheck2 size={18} /><span>الشروط والخصوصية</span></button><button className="nav-item"><MessageCircle size={18} /><span>تواصل معنا</span></button><div className="sidebar-footer"><div className="help-orb"><Wrench size={19} /></div><div><div className="text-xs font-bold text-[#40584d]">تحتاج مساعدة؟</div><div className="mt-1 text-[10px] text-[#94a097]">فريقنا معك دائماً</div></div></div></aside>;
}

export default function Home({ initialRole = "homeowner" }: { initialRole?: Role }) {
  const [role, setRole] = useState<Role>(initialRole);
  const [tab, setTab] = useState<Tab>("home");
  const [modal, setModal] = useState<"request" | "tech" | null>(null);
  const [selectedTech, setSelectedTech] = useState<Technician | null>(null);
  const [notice, setNotice] = useState("");

  const pageTitle = useMemo(() => role === "admin" ? "نظرة عامة" : role === "technician" ? "مساحتي" : "الرئيسية", [role]);
  const handleNew = () => setModal("request");
  const handleCreate = () => { setModal(null); setNotice("تم نشر طلبك بنجاح — سيصلك أول عرض قريباً"); setTimeout(() => setNotice(""), 3500); };
  const handleViewTech = (tech: Technician) => { setSelectedTech(tech); setModal("tech"); };

  const content = tab === "home"
    ? <>{role === "homeowner" && <HomeDashboard onNewRequest={handleNew} onViewTech={handleViewTech} />}{role === "technician" && <TechnicianWorkspace onViewTech={handleViewTech} />}{role === "admin" && <AdminWorkspace />}</>
    : tab === "requests" ? <RequestsView role={role} onNewRequest={handleNew} />
    : tab === "messages" ? <MessagesView />
    : tab === "technicians" ? <DirectoryView onViewTech={handleViewTech} />
    : <ProfileView role={role} />;

  return <div dir="rtl" className="app-shell"><AppHeader role={role} setRole={(next) => { setRole(next); setTab("home"); }} onNewRequest={handleNew} /><div className="app-layout"><Sidebar tab={tab} setTab={setTab} role={role} /><main className="main-content"><div className="mobile-title"><div><div className="eyebrow">الأربعاء، 29 أكتوبر 2026</div><h1>{pageTitle}</h1></div><button className="icon-button"><Bell size={18} /></button></div>{content}</main></div>{notice && <div className="toast"><div className="toast-check"><Check size={15} /></div>{notice}</div>}{modal === "request" && <NewRequestModal onClose={() => setModal(null)} onCreate={handleCreate} />}{modal === "tech" && selectedTech && <TechProfileModal tech={selectedTech} onClose={() => setModal(null)} />}</div>;
}
