import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import Home from "./Home";

export default function AdminPanel() {
  const [, navigate] = useLocation();
  const [state, setState] = useState<"loading" | "ok" | "unauthorized">("loading");
  useEffect(() => {
    fetch("/api/admin/me", { credentials: "include" }).then((response) => { setState(response.ok ? "ok" : "unauthorized"); if (!response.ok) navigate("/admin/login"); }).catch(() => { setState("unauthorized"); navigate("/admin/login"); });
  }, [navigate]);
  if (state === "loading") return <div className="flex min-h-screen items-center justify-center bg-[#f5f6f1] text-sm font-bold text-[#486354]" dir="rtl">جارٍ التحقق من جلسة المشرف...</div>;
  if (state !== "ok") return null;
  return <Home initialRole="admin" />;
}
