import type { Express, Request, Response, NextFunction } from "express";
import { commissionSettings } from "../drizzle/schema";
import { ADMIN_EMAIL } from "../shared/admin";
import * as db from "./db";
import { clearAdminCookie, getAdminSession, isValidAdminEmail, loginAdmin, MIN_PASSWORD_LENGTH, setAdminCookie, setupAdmin } from "./adminAuth";
import { recordCommissionDue, recordWalletPayment } from "./wallet";

function jsonError(res: Response, status: number, code: string, message: string) { res.status(status).json({ ok: false, code, message }); }

export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const account = await getAdminSession(req);
  if (!account) return jsonError(res, 401, "ADMIN_AUTH_REQUIRED", "يجب تسجيل الدخول إلى لوحة المشرف");
  res.locals.admin = account;
  next();
}

export function registerAdminRoutes(app: Express) {
  app.get("/api/admin/setup-status", async (_req, res) => {
    const account = await db.getAdminAccount(ADMIN_EMAIL);
    res.json({ ok: true, email: ADMIN_EMAIL, setupComplete: Boolean(account), minPasswordLength: MIN_PASSWORD_LENGTH });
  });

  app.post("/api/admin/setup", async (req, res) => {
    const email = typeof req.body?.email === "string" ? req.body.email : "";
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!isValidAdminEmail(email)) return jsonError(res, 403, "ADMIN_EMAIL_MISMATCH", "البريد غير مخوّل للمشرف");
    try {
      await setupAdmin(email, password);
      const token = await loginAdmin(email, password);
      setAdminCookie(res, token);
      res.status(201).json({ ok: true, email: ADMIN_EMAIL });
    } catch (error) {
      const code = error instanceof Error ? error.message : "SETUP_FAILED";
      const status = code === "ADMIN_ALREADY_SETUP" ? 409 : 400;
      return jsonError(res, status, code, code === "WEAK_PASSWORD" ? `كلمة المرور يجب أن تكون ${MIN_PASSWORD_LENGTH} حرفاً على الأقل وتحتوي أحرفاً وأرقاماً` : "تعذر إعداد حساب المشرف");
    }
  });

  app.post("/api/admin/login", async (req, res) => {
    const email = typeof req.body?.email === "string" ? req.body.email : "";
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    try {
      const token = await loginAdmin(email, password);
      setAdminCookie(res, token);
      res.json({ ok: true, email: ADMIN_EMAIL });
    } catch (error) {
      const code = error instanceof Error ? error.message : "INVALID_CREDENTIALS";
      const status = code === "ADMIN_LOCKED" ? 429 : 401;
      return jsonError(res, status, code, code === "ADMIN_LOCKED" ? "تم إيقاف المحاولات مؤقتاً، حاول بعد 15 دقيقة" : "البريد أو كلمة المرور غير صحيحة");
    }
  });

  app.post("/api/admin/logout", (_req, res) => { clearAdminCookie(res); res.json({ ok: true }); });
  app.get("/api/admin/me", requireAdmin, (_req, res) => res.json({ ok: true, email: ADMIN_EMAIL }));

  app.get("/api/catalog/provinces", async (_req, res) => res.json({ ok: true, data: await db.listProvinces() }));
  app.get("/api/catalog/services", async (_req, res) => res.json({ ok: true, data: await db.listServices() }));
  app.get("/api/technicians", async (req, res) => {
    const provinceId = Number(req.query.provinceId);
    const serviceId = Number(req.query.serviceId);
    res.json({ ok: true, data: await db.listTechnicians({ provinceId: Number.isInteger(provinceId) && provinceId > 0 ? provinceId : undefined, serviceId: Number.isInteger(serviceId) && serviceId > 0 ? serviceId : undefined }) });
  });

  app.get("/api/admin/settings/commission", requireAdmin, async (_req, res) => {
    const setting = await db.getCommissionSetting();
    res.json({ ok: true, data: setting ?? { ratePercent: "10.00", collectionMethod: "زين كاش", freeLaunchUntil: null, freezeThreshold: 100000 } });
  });

  app.put("/api/admin/settings/commission", requireAdmin, async (req, res) => {
    const ratePercent = Number(req.body?.ratePercent);
    const collectionMethod = typeof req.body?.collectionMethod === "string" ? req.body.collectionMethod.trim() : "";
    const freezeThreshold = Number(req.body?.freezeThreshold);
    if (!Number.isFinite(ratePercent) || ratePercent < 0 || ratePercent > 100 || !collectionMethod || !Number.isInteger(freezeThreshold) || freezeThreshold < 0) return jsonError(res, 400, "INVALID_SETTINGS", "إعدادات العمولة غير صحيحة");
    await db.upsertCommissionSetting({ ratePercent: ratePercent.toFixed(2), collectionMethod, freezeThreshold, updatedByAdminId: res.locals.admin.id });
    res.json({ ok: true });
  });

  app.get("/api/admin/wallets", requireAdmin, async (_req, res) => res.json({ ok: true, data: await db.listWallets() }));
  app.post("/api/admin/wallets/:technicianId/commission", requireAdmin, async (req, res) => {
    const technicianId = Number(req.params.technicianId);
    const requestId = Number(req.body?.requestId);
    const serviceAmount = Number(req.body?.serviceAmount);
    if (!Number.isInteger(technicianId) || !Number.isInteger(requestId) || !Number.isInteger(serviceAmount)) return jsonError(res, 400, "INVALID_COMMISSION", "بيانات العمولة غير صحيحة");
    try { res.json({ ok: true, data: await recordCommissionDue({ technicianId, requestId, serviceAmount }) }); }
    catch { return jsonError(res, 400, "COMMISSION_FAILED", "تعذر تسجيل العمولة"); }
  });
  app.post("/api/admin/wallets/:technicianId/payment", requireAdmin, async (req, res) => {
    const technicianId = Number(req.params.technicianId);
    const amount = Number(req.body?.amount);
    if (!Number.isInteger(technicianId) || !Number.isInteger(amount)) return jsonError(res, 400, "INVALID_PAYMENT", "بيانات السداد غير صحيحة");
    try { res.json({ ok: true, data: await recordWalletPayment({ technicianId, amount, note: req.body?.note }) }); }
    catch { return jsonError(res, 400, "PAYMENT_FAILED", "تعذر تسجيل السداد"); }
  });
}
