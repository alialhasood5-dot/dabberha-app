import { sql } from "drizzle-orm";
import { walletLedger, wallets } from "../drizzle/schema";
import * as db from "./db";

export async function calculateCommission(serviceAmount: number) {
  if (!Number.isInteger(serviceAmount) || serviceAmount < 0) throw new Error("INVALID_SERVICE_AMOUNT");
  const setting = await db.getCommissionSetting();
  const freeLaunchUntil = setting?.freeLaunchUntil?.getTime() ?? 0;
  if (freeLaunchUntil > Date.now()) return { amount: 0, ratePercent: 0, freeLaunch: true };
  const ratePercent = Number(setting?.ratePercent ?? "10.00");
  return { amount: Math.round(serviceAmount * ratePercent / 100), ratePercent, freeLaunch: false };
}

export async function recordCommissionDue(input: { technicianId: number; requestId: number; serviceAmount: number }) {
  const database = await db.getDb();
  if (!database) throw new Error("Database is not available");
  const commission = await calculateCommission(input.serviceAmount);
  if (commission.amount === 0) return commission;
  await database.insert(walletLedger).values({ technicianId: input.technicianId, requestId: input.requestId, entryType: "commission_due", amount: commission.amount, note: `عمولة ${commission.ratePercent}%` });
  await database.insert(wallets).values({ technicianId: input.technicianId, balanceDue: commission.amount }).onDuplicateKeyUpdate({ set: { balanceDue: sql`${wallets.balanceDue} + ${commission.amount}` } });
  const setting = await db.getCommissionSetting();
  if (setting && commission.amount >= setting.freezeThreshold) await database.update(wallets).set({ isFrozen: 1 }).where(sql`${wallets.technicianId} = ${input.technicianId}`);
  return commission;
}

export async function recordWalletPayment(input: { technicianId: number; amount: number; note?: string }) {
  const database = await db.getDb();
  if (!database) throw new Error("Database is not available");
  if (!Number.isInteger(input.amount) || input.amount <= 0) throw new Error("INVALID_PAYMENT_AMOUNT");
  const current = await db.getWallet(input.technicianId);
  const nextDue = Math.max(0, (current?.balanceDue ?? 0) - input.amount);
  await database.insert(walletLedger).values({ technicianId: input.technicianId, entryType: "payment", amount: input.amount, note: input.note ?? "سداد عمولة" });
  await database.insert(wallets).values({ technicianId: input.technicianId, balanceDue: nextDue, isFrozen: nextDue === 0 ? 0 : (current?.isFrozen ?? 0) }).onDuplicateKeyUpdate({ set: { balanceDue: nextDue, isFrozen: nextDue === 0 ? 0 : (current?.isFrozen ?? 0) } });
  return db.getWallet(input.technicianId);
}
