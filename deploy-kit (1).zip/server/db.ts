import { and, asc, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { adminAccounts, commissionSettings, provinces, services, technicianProfiles, technicianProvinces, technicianServices, users, wallets, type AdminAccount, type InsertUser } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "phone", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId || (user.email && user.email.toLowerCase() === ENV.adminEmail.toLowerCase())) { values.role = "admin"; updateSet.role = "admin"; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getAdminAccount(email: string): Promise<AdminAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  try {
    const result = await db.select().from(adminAccounts).where(eq(adminAccounts.email, email.toLowerCase())).limit(1);
    return result[0];
  } catch (error) {
    console.warn("[Database] Admin table is not ready:", error instanceof Error ? error.message : "unknown error");
    return undefined;
  }
}

export async function createAdminAccount(input: { email: string; passwordHash: string; passwordSalt: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(adminAccounts).values({ email: input.email.toLowerCase(), passwordHash: input.passwordHash, passwordSalt: input.passwordSalt });
}

export async function recordAdminFailure(id: number, lockedUntil: Date | null, failedAttempts: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(adminAccounts).set({ failedAttempts, lockedUntil }).where(eq(adminAccounts.id, id));
}

export async function recordAdminLogin(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(adminAccounts).set({ failedAttempts: 0, lockedUntil: null, lastLoginAt: new Date() }).where(eq(adminAccounts.id, id));
}

export async function listProvinces() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(provinces).where(eq(provinces.isActive, 1)).orderBy(asc(provinces.sortOrder), asc(provinces.name));
}

export async function listServices() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(services).where(eq(services.isActive, 1)).orderBy(asc(services.name));
}

export async function seedCatalog() {
  const db = await getDb();
  if (!db) return;
  const provinceNames = ["بغداد", "البصرة", "نينوى", "أربيل", "النجف", "كربلاء", "ذي قار", "الأنبار", "ديالى", "بابل", "كركوك", "واسط", "صلاح الدين", "ميسان", "المثنى", "القادسية", "دهوك", "السليمانية"];
  const serviceNames = ["كهرباء", "تكييف وتبريد", "سباكة ومجاري", "بناء وترميم", "صبغ وديكور", "نجارة", "تنظيف"];
  const existingProvinces = await listProvinces();
  const existingServices = await listServices();
  for (let i = 0; i < provinceNames.length; i++) if (!existingProvinces.some((item) => item.name === provinceNames[i])) await db.insert(provinces).values({ name: provinceNames[i], sortOrder: i + 1 });
  for (const name of serviceNames) if (!existingServices.some((item) => item.name === name)) await db.insert(services).values({ name });
}

export async function getCommissionSetting() {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(commissionSettings).orderBy(desc(commissionSettings.id)).limit(1);
  return result[0];
}

export async function upsertCommissionSetting(input: { ratePercent: string; collectionMethod: string; freezeThreshold: number; updatedByAdminId: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const current = await getCommissionSetting();
  if (current) {
    await db.update(commissionSettings).set(input).where(eq(commissionSettings.id, current.id));
  } else {
    await db.insert(commissionSettings).values(input);
  }
}

export async function getWallet(technicianId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(wallets).where(eq(wallets.technicianId, technicianId)).limit(1);
  return result[0];
}

export async function listWallets() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(wallets).orderBy(desc(wallets.balanceDue));
}

export async function listTechnicians(filters: { provinceId?: number; serviceId?: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(users.role, "technician" as const), eq(technicianProfiles.verificationStatus, "verified" as const)];
  if (filters.provinceId) conditions.push(eq(technicianProvinces.provinceId, filters.provinceId));
  if (filters.serviceId) conditions.push(eq(technicianServices.serviceId, filters.serviceId));
  return db.selectDistinct({ id: technicianProfiles.id, userId: users.id, name: users.name, provinceId: technicianProvinces.provinceId, serviceId: technicianServices.serviceId, verificationStatus: technicianProfiles.verificationStatus, averageRating: technicianProfiles.averageRating, completedJobs: technicianProfiles.completedJobs })
    .from(technicianProfiles)
    .innerJoin(users, eq(users.id, technicianProfiles.userId))
    .innerJoin(technicianProvinces, eq(technicianProvinces.technicianId, technicianProfiles.id))
    .innerJoin(technicianServices, eq(technicianServices.technicianId, technicianProfiles.id))
    .where(and(...conditions));
}
