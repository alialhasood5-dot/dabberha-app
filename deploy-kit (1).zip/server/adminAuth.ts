import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { SignJWT, jwtVerify } from "jose";
import { parse as parseCookieHeader } from "cookie";
import type { Request, Response } from "express";
import { ADMIN_COOKIE_NAME, ADMIN_SESSION_MS } from "../shared/admin";
import { ENV } from "./_core/env";
import * as db from "./db";

const scrypt = promisify(scryptCallback);
const MIN_PASSWORD_LENGTH = 12;
const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MS = 15 * 60 * 1000;

function normalizeEmail(email: string) { return email.trim().toLowerCase(); }
function getSecret() {
  const raw = ENV.cookieSecret;
  if (!raw) throw new Error("MANUS_JWT_SECRET is unavailable");
  return new TextEncoder().encode(`${raw}:dabrha-admin`);
}

export function isValidAdminEmail(email: string) { return normalizeEmail(email) === ENV.adminEmail; }
export function validateAdminPassword(password: string) {
  return password.length >= MIN_PASSWORD_LENGTH && /[A-Za-z]/.test(password) && /\d/.test(password);
}

async function hashPassword(password: string, salt = randomBytes(32)) {
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return { hash: derived.toString("base64"), salt: salt.toString("base64") };
}

async function verifyPassword(password: string, hash: string, salt: string) {
  const derived = (await scrypt(password, Buffer.from(salt, "base64"), 64)) as Buffer;
  const expected = Buffer.from(hash, "base64");
  return expected.length === derived.length && timingSafeEqual(expected, derived);
}

export async function setupAdmin(email: string, password: string) {
  const normalized = normalizeEmail(email);
  if (!isValidAdminEmail(normalized)) throw new Error("ADMIN_EMAIL_MISMATCH");
  if (!validateAdminPassword(password)) throw new Error("WEAK_PASSWORD");
  const existing = await db.getAdminAccount(normalized);
  if (existing) throw new Error("ADMIN_ALREADY_SETUP");
  const { hash, salt } = await hashPassword(password);
  await db.createAdminAccount({ email: normalized, passwordHash: hash, passwordSalt: salt });
}

export async function loginAdmin(email: string, password: string) {
  const normalized = normalizeEmail(email);
  const account = await db.getAdminAccount(normalized);
  if (!account || !isValidAdminEmail(normalized)) throw new Error("INVALID_CREDENTIALS");
  if (account.lockedUntil && account.lockedUntil.getTime() > Date.now()) throw new Error("ADMIN_LOCKED");
  const valid = await verifyPassword(password, account.passwordHash, account.passwordSalt);
  if (!valid) {
    const attempts = account.failedAttempts + 1;
    await db.recordAdminFailure(account.id, attempts >= MAX_FAILED_ATTEMPTS ? new Date(Date.now() + LOCK_MS) : null, attempts);
    throw new Error("INVALID_CREDENTIALS");
  }
  await db.recordAdminLogin(account.id);
  return createAdminSession(account.email);
}

async function createAdminSession(email: string) {
  return new SignJWT({ email, scope: "admin" })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuedAt()
    .setExpirationTime(Math.floor((Date.now() + ADMIN_SESSION_MS) / 1000))
    .sign(getSecret());
}

export async function getAdminSession(req: Request) {
  const token = parseCookieHeader(req.headers.cookie ?? "")[ADMIN_COOKIE_NAME];
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecret(), { algorithms: ["HS256"] });
    if (payload.scope !== "admin" || typeof payload.email !== "string" || !isValidAdminEmail(payload.email)) return null;
    const account = await db.getAdminAccount(payload.email);
    return account ?? null;
  } catch { return null; }
}

export function setAdminCookie(res: Response, token: string) {
  res.cookie(ADMIN_COOKIE_NAME, token, { httpOnly: true, secure: true, sameSite: "none", path: "/", maxAge: ADMIN_SESSION_MS });
}
export function clearAdminCookie(res: Response) { res.clearCookie(ADMIN_COOKIE_NAME, { httpOnly: true, secure: true, sameSite: "none", path: "/" }); }
export { MIN_PASSWORD_LENGTH };
