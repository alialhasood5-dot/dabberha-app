import "dotenv/config";
import { seedCatalog } from "./db";

await seedCatalog();
console.log("Dabrha catalog seeded");
process.exit(0);
